cd ../BUILD
echo "Melakukan Compiling Untuk Game Sokoban.."
cmake -S .. -G "MinGW Makefiles" --fresh
make
