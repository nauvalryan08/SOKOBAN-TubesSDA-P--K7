/*** Identitas ***/
// Nama : Muhamad Sopiana Argiansah
// NIM: 241524016
// Kelas: 1A-D4
// Prodi: D4-Teknik Informatika
// Jurusan: Teknik Komputer dan Informatika
// Politeknik Negeri Bandung

#ifndef BOOLEAN_H
#define BOOLEAN_H

#define false 0
#define true 1

typedef int boolean;

#endif
