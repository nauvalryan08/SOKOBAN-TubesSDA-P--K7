#ifndef TUTORIAL_H
#define TUTORIAL_H
#define KEY_ESC 27

#include <curses.h>
#include <string.h>
#include <locale.h>

void show_tutorial_screen();

#endif