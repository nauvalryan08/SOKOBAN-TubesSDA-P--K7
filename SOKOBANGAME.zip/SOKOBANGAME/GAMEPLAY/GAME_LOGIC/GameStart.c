#include "GameStart.h"

//==========================================================//
//== Method untuk menjalankan Level berdasarkan Parameter ==//
//==========================================================//
/* {Sopian} */

void start_level (RoomLayout *room, LevelData *level, ChapterData * current_chapter, const char *username) {

    Stack StackUndo;
    Queue replayQueue;
    int keyOutput = 0;
    int prev_lines = LINES;
    int prev_cols = COLS;

    ScoreData scoreData = {0};
    time_t start_time = time(NULL);

    Button btn = {2, LINES - 10, 20, 4, "Exit"};

    const char **map = level->map;

    stack_init(&StackUndo);
    initQueue(&replayQueue);

    parse_room(room, map);      //parsing data berdasarkan map

    //simpan data roomLayout ke undo stack
    save_state(&StackUndo, room);

    getch();
    while (1) {
        prev_lines = LINES;
        prev_cols = COLS;

        handle_resize(&prev_lines, &prev_cols);

        update_box_activation_status (room);
        update_finish_activation_status (room);

        room->finish.is_activated = true;
        print_room (level->level_name, map, room, scoreData, &btn);

        handle_input (room, map, &StackUndo, &replayQueue, &keyOutput, &btn, username);

        if (keyOutput == 27) { // ESC key pressed
            break; // Exit game loop
        }

        if (is_victory(room)) {
            // Bersihkan layar dulu kalau mau
            scoreData.time = time(NULL) - start_time;
            game_finished(room, level, current_chapter, &replayQueue, scoreData, username);
            break; // Keluar dari loop game
        }
    }

    //bersihkan chace pada stack
    stack_clear(&StackUndo);
    clearQueue(&replayQueue);
}


void game_finished(RoomLayout *room, LevelData *level, ChapterData *current_chapter, Queue *replayQueue, ScoreData scoreData, const char *username) {
    clear();
    int max_y, max_x;
    getmaxyx(stdscr, max_y, max_x);

    const char *msg1 = "^_^ KAMU MENANG! ^_^";
    const char *msg2 = "1. Replay  | 2. Next Stage  | 3. Quit";

    mvprintw(max_y / 2 - 2, (max_x - strlen(msg1)) / 2, "%s", msg1);
    mvprintw(max_y / 2, (max_x - strlen(msg2)) / 2, "%s", msg2);
    refresh();

    // Unlock level berikutnya
    level->is_finished = true;
    Ptree node = findTreeNode(current_chapter->ChapterTree, (void*)level, compareDataID);
    if (node != NULL) {
        unlock_child_if_parent_finished(node);
    }

    // Simpan replay ke database
    char dataID[64];
    sprintf(dataID, "%s_%ld", level->level_id, time(NULL)); // Format unik ID
    saveReplayToDatabase(replayQueue, username, level->level_id, dataID, scoreData);

    // Pilihan pasca menang
    int ch;
    while (1) {
        ch = getch();
        if (ch == '1') {
            // Replay langkah yang baru saja dimainkan
            Queue q;
            initReplayQueue(&q);
            if (loadReplayRecord(&q, username, dataID)) {
                playReplay(room, *level, &q);
            } else {
                mvprintw(max_y / 2 + 3, (max_x - 30) / 2, "Replay tidak ditemukan!");
                getch();
            }
            clearQueue(&q);
            break;
        } else if (ch == '2') {
            // lanjut ke stage berikutnya
            break;
        } else if (ch == '3' || ch == 27) {
            // keluar
            endwin();
            exit(0);
        }
    }
}

